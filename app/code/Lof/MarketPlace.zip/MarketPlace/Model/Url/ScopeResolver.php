<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Lof\MarketPlace\Model\Url;

class ScopeResolver extends \Magento\Framework\Url\ScopeResolver
{
}
