/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
var config = {
	map: {
		"*": {
			conflict: "Lof_MarketPlace/js/conflict",
			owlcarousel: "Lof_MarketPlace/js/owl.carousel",
			boostrap: "Lof_MarketPlace/js/bootstrap.min",
		}
	}
};